Copyright (c) 2014 Yahoo! Inc.
Copyrights licensed under the MIT License. See the accompanying LICENSE file for terms.

Authors: Martin Saveski (http://www.time.mk/msaveski/) and Amin Mantrach (http://iridia.ulb.ac.be/~amantrac/)



Joint Non-negative Matrix Factorization


This repository contains the MATLAB implementation of the Joint Non-negative Matrix Factorization (JNMF) and Joint Non-negative Matrix Factorization with Graph Regularization methods for cold-start recommendations.

An example of how to use the MATLAB functions is given in the DEMO.m.

